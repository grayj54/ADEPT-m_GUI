function y=a_linear(x,xt,xb,yt,yb)

y=yt+(yb-yt)/(xb-xt)*(x-xt);
function [dev kerr]=a_rcustom(p,dev,fout,ltitle,nlayer,thick)
global CONST VERBOSE

dev.reg(nlayer).describe=ltitle;

ip(1).aliases={'t_A' 't_nm' 't_um' 't_cm'}; % this should be the same for all layer types
ip(1).type='number';
ip(1).n=[1 1;1 1];
ip(1).range=[eps inf];
ip(1).values=[];
ip(1).default=[-999];

ip(2).aliases={'model' 'semi'}; % a_rlayer looks for this
ip(2).type='string';
ip(2).n=[1 1;1 1];
ip(2).range=[];
ip(2).values={'custom' 'custom(T)' 'Si' 'silicon'};
ip(2).default={'custom'};

%----------------------------------------------------

ip(3).aliases={'chi'}; % electron affinity (eV)
ip(3).type='number';
ip(3).n=[1 1;1 2];
ip(3).range=[-inf inf];
ip(3).values=[];
ip(3).default=[4];

ip(4).aliases={'Eg' 'eg'}; % bandgap (eV)
ip(4).type='number';
ip(4).n=[1 1;1 2];
ip(4).range=[0 inf];
ip(4).values=[];
ip(4).default=[1];

ip(5).aliases={'ks'}; % dielectic constant
ip(5).type='number';
ip(5).n=[1 1;1 2];
ip(5).range=[1 inf];
ip(5).values=[];
ip(5).default=[10];

ip(6).aliases={'Nc'}; % Conduction band effective density of states (#/cm^3)
ip(6).type='number';
ip(6).n=[1 1;1 2];
ip(6).range=[realmin inf];
ip(6).values=[];
ip(6).default=[1e19];

ip(7).aliases={'Nv'}; % Valence band effective density of states (#/cm^3)
ip(7).type='number';
ip(7).n=[1 1;1 2];
ip(7).range=[realmin inf];
ip(7).values=[];
ip(7).default=[1e19];

ip(8).aliases={'Nc.tot'}; % Conduction band "actual" density of states (#/cm^3)
ip(8).type='number';
ip(8).n=[1 1;1 2];
ip(8).range=[realmin inf];
ip(8).values=[];
ip(8).default=[inf];

ip(9).aliases={'Nv.tot'}; % Valence band "actual" density of states (#/cm^3)
ip(9).type='number';
ip(9).n=[1 1;1 2];
ip(9).range=[realmin inf];
ip(9).values=[];
ip(9).default=[inf];

ip(10).aliases={'vth.n'}; % electron thermal velocity (cm/s)
ip(10).type='number';
ip(10).n=[1 1;1 2];
ip(10).range=[0 inf];
ip(10).values=[];
ip(10).default=[0];

ip(11).aliases={'vth.p'}; % hole thermal velocity (cm/s)
ip(11).type='number';
ip(11).n=[1 1;1 2];
ip(11).range=[0 inf];
ip(11).values=[];
ip(11).default=[0];

ip(12).aliases={'Nd+' 'ndp' 'Ndp' 'N.ndp'}; % fixed fully ionized dopant (#/cm^3)
ip(12).type='number';
ip(12).n=[1 inf;1 2];
ip(12).range=[0 inf];
ip(12).values=[];
ip(12).default=[0];
ip(12).indexed=1;

ip(13).aliases={'Na-' 'nam' 'Nam' 'N.nam'}; % fixed fully ionized dopant (#/cm^3)
ip(13).type='number';
ip(13).n=[1 inf;1 2];
ip(13).range=[0 inf];
ip(13).values={'file'}; % file input
ip(13).default=[0];
ip(13).indexed=1;

ip(14).aliases={'un'}; % electron mobility (cm^2/V-s)
ip(14).type='number';
ip(14).n=[1 1;1 2];
ip(14).range=[realmin inf];
ip(14).values={'*'};
ip(14).default=[100];

ip(15).aliases={'up'}; % hole mobility (cm^2/V-s)
ip(15).type='number';
ip(15).n=[1 1;1 2];
ip(15).range=[realmin inf];
ip(15).values={'*'};
ip(15).default=[100];

ip(16).aliases={'Et.shr' 'et.shr'}; % deep-level trap with negligible trapped charge. et=Et-Ei
ip(16).type='number';
ip(16).n=[1 inf;1 2];
ip(16).range=[-inf inf];
ip(16).values=[];
ip(16).default=[0];

ip(17).aliases={'taun.shr'}; % electron lifetime
ip(17).type='number';
ip(17).n=[1 inf;1 2];
ip(17).range=[1e-50 inf];
ip(17).values={'*'};
ip(17).default=[1e100];

ip(18).aliases={'taup.shr'}; % hole lifetime
ip(18).type='number';
ip(18).n=[1 inf;1 2];
ip(18).range=[1e-50 inf];
ip(18).values={'*'};
ip(18).default=[1e100];

ip(19).aliases={'B.rad' 'B'}; % radiative recombination coeff.
ip(19).type='number';
ip(19).n=[1 1;1 2];
ip(19).range=[0 inf];
ip(19).values={'*'};
ip(19).default=[0];

ip(20).aliases={'Cn.auger' 'Cn'}; % Auger recombination coeff for electrons
ip(20).type='number';
ip(20).n=[1 1;1 2];
ip(20).range=[0 inf];
ip(20).values={'*'};
ip(20).default=[0];

ip(21).aliases={'Cp.auger' 'Cp'}; % Auger recombination coeff for holes
ip(21).type='number';
ip(21).n=[1 1;1 2];
ip(21).range=[0 inf];
ip(21).values={'*'};
ip(21).default=[0];

ip(22).aliases={'alpha_model' 'alpha_model.opt'}; % for creation of e-h pairs
ip(22).type='string';
ip(22).n=[1 1;1 1];
ip(22).range=[];
ip(22).values={'none' 'simple' 'equation' 'file'};
ip(22).default={'none'};

ip(23).aliases={'N.d'}; % donor trap density
ip(23).type='number';
ip(23).n=[1 inf;1 2];
ip(23).range=[0 inf];
ip(23).values={'*'};
ip(23).default=0;
ip(23).indexed=1;

ip(24).aliases={'Et.d' 'et.d'}; % Et.d=Ec-Et
ip(24).type='number';
ip(24).n=[1 inf;1 2];
ip(24).range=[-inf inf];
ip(24).values=[];
ip(24).default=-1;

ip(25).aliases={'g.d'}; % degeneracy factor
ip(25).type='number';
ip(25).n=[1 inf;1 1];
ip(25).range=[1 inf];
ip(25).values=[];
ip(25).default=2; % standard value

ip(26).aliases={'cp.d'}; % capture cross-esction for holes (cm^2)
ip(26).type='number';
ip(26).n=[1 inf;1 2];
ip(26).range=[realmin inf];
ip(26).values=[];
ip(26).default=1e-30;

ip(27).aliases={'cn.d'}; % capture cross-esction for electrons (cm^2)
ip(27).type='number';
ip(27).n=[1 inf;1 2];
ip(27).range=[realmin inf];
ip(27).values=[];
ip(27).default=1e-30;

ip(28).aliases={'N.a'}; % acceptor trap density
ip(28).type='number';
ip(28).n=[1 inf;1 2];
ip(28).range=[0 inf];
ip(28).values={'*'};
ip(28).default=0;
ip(28).indexed=1;

ip(29).aliases={'Et.a'}; % Et.slt=Et-Ev
ip(29).type='number';
ip(29).n=[1 inf;1 2];
ip(29).range=[-inf inf];
ip(29).values=[];
ip(29).default=-1;

ip(30).aliases={'g.a'}; % degeneracy factor
ip(30).type='number';
ip(30).n=[1 inf;1 1];
ip(30).range=[1 inf];
ip(30).values=[];
ip(30).default=4; % standard value

ip(31).aliases={'cp.a'}; % capture cross-esction for holes (cm^2)
ip(31).type='number';
ip(31).n=[1 inf;1 2];
ip(31).range=[realmin inf];
ip(31).values=[];
ip(31).default=1e-30;

ip(32).aliases={'cn.a'}; % capture cross-esction for electrons (cm^2)
ip(32).type='number';
ip(32).n=[1 inf;1 2];
ip(32).range=[realmin inf];
ip(32).values=[];
ip(32).default=1e-30;

ip(33).aliases={'N.slt'}; % SLT trap density
ip(33).type='number';
ip(33).n=[1 inf;1 2];
ip(33).range=[0 inf];
ip(33).values=[];
ip(33).default=[0];

ip(34).aliases={'type.slt'}; % donor-like or acceptor-like
ip(34).type='string';
ip(34).n=[1 inf;1 1];
ip(34).range=[];
ip(34).values={'donor' 'acceptor' 'off'};
ip(34).default={'off'};

ip(35).aliases={'Et.slt' 'et.slt'}; % Et.slt=Et-Ei
ip(35).type='number';
ip(35).n=[1 inf;1 2];
ip(35).range=[-inf inf];
ip(35).values=[];
ip(35).default=[0];

ip(36).aliases={'g.slt'}; % degeneracy factor
ip(36).type='number';
ip(36).n=[1 inf;1 1];
ip(36).range=[1 inf];
ip(36).values=[];
ip(36).default=1;

ip(37).aliases={'cp.slt'}; % capture cross-section for holes (cm^2)
ip(37).type='number';
ip(37).n=[1 inf;1 2];
ip(37).range=[realmin inf];
ip(37).values=[];
ip(37).default=[realmin];

ip(38).aliases={'cn.slt'}; % capture cross-section for electrons (cm^2)
ip(38).type='number';
ip(38).n=[1 inf;1 2];
ip(38).range=[realmin inf];
ip(38).values=[];
ip(38).default=[realmin];

ip(39).aliases={'taup.slt'}; % hole lifetime to compute cp=1/(taup*vth*Nt)
ip(39).type='number';
ip(39).n=[1 inf;1 2];
ip(39).range=[-1 inf];
ip(39).values={'*'};
ip(39).default=[-1];

ip(40).aliases={'taun.slt'}; % electron lifetime to compute cn=1/(taun*vth*Nt)
ip(40).type='number';
ip(40).n=[1 inf;1 2];
ip(40).range=[-1 inf];
ip(40).values={'*'};
ip(40).default=[-1];

ip(41).aliases={'N.mv3'}; % 3-level multivalent trap density
ip(41).type='number';
ip(41).n=[1 inf;1 2];
ip(41).range=[0 inf];
ip(41).values=[];
ip(41).default=[0];

ip(42).aliases={'Etp.mv3'}; % Etp.mv3=Et-Ev
ip(42).type='number';
ip(42).n=[1 inf;1 2];
ip(42).range=[-inf inf];
ip(42).values=[];
ip(42).default=[0];

ip(43).aliases={'Etm.mv3'}; % Etm.mv3=Et-Ev
ip(43).type='number';
ip(43).n=[1 inf;1 2];
ip(43).range=[-inf inf];
ip(43).values=[];
ip(43).default=[0];

ip(44).aliases={'cpp.mv3'}; % capture cross-section for holes (cm^2)
ip(44).type='number';
ip(44).n=[1 inf;1 2];
ip(44).range=[0 inf];
ip(44).values=[];
ip(44).default=[1e-14];

ip(45).aliases={'cnp.mv3'}; % capture cross-section for electrons (cm^2)
ip(45).type='number';
ip(45).n=[1 inf;1 2];
ip(45).range=[0 inf];
ip(45).values=[];
ip(45).default=[1e-14];

ip(46).aliases={'cpm.mv3'}; % capture cross-section for holes (cm^2)
ip(46).type='number';
ip(46).n=[1 inf;1 2];
ip(46).range=[0 inf];
ip(46).values=[];
ip(46).default=[1e-14];

ip(47).aliases={'cnm.mv3'}; % capture cross-section for electrons (cm^2)
ip(47).type='number';
ip(47).n=[1 inf;1 2];
ip(47).range=[0 inf];
ip(47).values=[];
ip(47).default=[1e-14];

ip(48).aliases={'Eg.opt'}; % optical bandgap
ip(48).type='number';
ip(48).n=[1 inf;1 2];
ip(48).range=[-1 inf];
ip(48).values=[];
ip(48).default=[-1]; % defaults to electrical bandgap

ip(49).aliases={'A1.opt'}; % coeff for absorption formula
ip(49).type='number';
ip(49).n=[1 inf;1 2];
ip(49).range=[0 inf];
ip(49).values=[];
ip(49).default=[0]; 

ip(50).aliases={'A2.opt'}; % absorption power law for numerator
ip(50).type='number';
ip(50).n=[1 inf;1 1];
ip(50).range=[0 inf];
ip(50).values=[];
ip(50).default=[0]; 

ip(51).aliases={'A3.opt'}; % absorption power law for denomenator
ip(51).type='number';
ip(51).n=[1 inf;1 1];
ip(51).range=[0 inf];
ip(51).values=[];
ip(51).default=[0];

ip(52).aliases={'alpha_fc.opt'}; % free carrier absorption
ip(52).type='string';
ip(52).n=[1 1;1 1];
ip(52).range=[];
ip(52).values={'on' 'off'};
ip(52).default={'off'};

ip(53).aliases={'FCn.opt'}; % free carrier abs coeff for electrons (cm^-1*cm^3/um^B)
ip(53).type='number';
ip(53).n=[1 1;1 2];
ip(53).range=[0 inf];
ip(53).values=[];
ip(53).default=[0];

ip(54).aliases={'FCp.opt'}; % free carrier abs coeff for holes (cm^-1*cm^3/um^B)
ip(54).type='number';
ip(54).n=[1 1;1 2];
ip(54).range=[0 inf];
ip(54).values=[];
ip(54).default=[0];

ip(55).aliases={'Bn.opt'}; % free carrier power law for electrons (wl^Bn)
ip(55).type='number';
ip(55).n=[1 1;1 1];
ip(55).range=[-inf inf];
ip(55).values=[];
ip(55).default=[2];

ip(56).aliases={'Bp.opt'}; % free carrier power law for holes (wl^Bn)
ip(56).type='number';
ip(56).n=[1 1;1 1];
ip(56).range=[-inf inf];
ip(56).values=[];
ip(56).default=[2];

ip(57).aliases={'vth'}; % thermal velocity (cm/s)
ip(57).type='number';
ip(57).n=[1 1;1 2];
ip(57).range=[0 inf];
ip(57).values=[];
ip(57).default=[0];

ip(58).aliases={'btail'}; % band tails
ip(58).type='string';
ip(58).n=[1 1;1 1];
ip(58).range=[];
ip(58).values={'on' 'off'};
ip(58).default={'off'};

ip(59).aliases={'ktv.bt'}; % charicteristic energy of valence band tail (donor-like)
ip(59).type='number';
ip(59).n=[1 1;1 2];
ip(59).range=[realmin inf];
ip(59).values=[];
ip(59).default=[.026];

ip(60).aliases={'ktc.bt'}; % charicteristic energy of conduction band tail (acceptor-like)
ip(60).type='number';
ip(60).n=[1 1;1 2];
ip(60).range=[realmin inf];
ip(60).values=[];
ip(60).default=[.026];

ip(61).aliases={'dEv.bt'}; % delE above Ev at which exp. band tail starts (density is assumed constant between Ev and Ev.bt)
ip(61).type='number';
ip(61).n=[1 1;1 2];
ip(61).range=[0 inf]; % must be >= 0
ip(61).values=[];
ip(61).default=[0]; %defaults to Ev -- NOT CHANGEABLE

ip(62).aliases={'dEc.bt'}; % delE below Ec at which exp. band tail starts (density is assumed constant between Ec.bt and Ec)
ip(62).type='number';
ip(62).n=[1 1;1 2];
ip(62).range=[0 inf]; % must be >= 0
ip(62).values=[];
ip(62).default=[0]; % defaults to Ec -- NOT CHANGEABLE

ip(63).aliases={'Gv0.bt'}; % density of states at Ev.bt for valence band tail (#/cm3/eV)
ip(63).type='number';
ip(63).n=[1 1;1 2];
ip(63).range=[-1 inf];
ip(63).values=[];
ip(63).default=[-1]; % defaults to 2*pi*Nv/(kT*pi)^3/2*sqrt(kT)

ip(64).aliases={'Gc0.bt'}; % density of states at Ec.bt for conduction band tail (#/cm3/eV)
ip(64).type='number';
ip(64).n=[1 1;1 2];
ip(64).range=[-1 inf];
ip(64).values=[];
ip(64).default=[-1]; % defaults to 2*pi*Nc/(kT*pi)^3/2*sqrt(kT))

ip(65).aliases={'cpv.bt'}; % capture cross-section for holes (cm^2)
ip(65).type='number';
ip(65).n=[1 inf;1 2];
ip(65).range=[realmin inf];
ip(65).values={};
ip(65).default=[1e-14];

ip(66).aliases={'cnv.bt'}; % capture cross-section for electrons (cm^2)
ip(66).type='number';
ip(66).n=[1 inf;1 2];
ip(66).range=[realmin inf];
ip(66).values={};
ip(66).default=[1e-14];

ip(67).aliases={'cpc.bt'}; % capture cross-section for holes (cm^2)
ip(67).type='number';
ip(67).n=[1 inf;1 2];
ip(67).range=[realmin inf];
ip(67).values={};
ip(67).default=[1e-14];

ip(68).aliases={'cnc.bt'}; % capture cross-section for electrons (cm^2)
ip(68).type='number';
ip(68).n=[1 inf;1 2];
ip(68).range=[realmin inf];
ip(68).values={};
ip(68).default=[1e-14];

ip(69).aliases={'nlaguerre.bt'}; % # of points for Gauss-Laguerre quadrature 
ip(69).type='number';
ip(69).n=[1 1;1 1];
ip(69).range=[2 100]; 
ip(69).values={};
ip(69).default=[15];

ip(70).aliases={'maxEstep.bt'}; % max intergtion step size between (Ev & Ev.bt) and (Ec.bt & Ec)
ip(70).type='number';
ip(70).n=[1 1;1 1];
ip(70).range=[-1 inf];
ip(70).values={};
ip(70).default=[-1]; % defaults to kT (not implemented)

ip(71).aliases={'gv.bt'}; % degeneracy factor
ip(71).type='number';
ip(71).n=[1 inf;1 1];
ip(71).range=[1 inf];
ip(71).values=[];
ip(71).default=[2]; % standard value for donors

ip(72).aliases={'gc.bt'}; % degeneracy factor
ip(72).type='number';
ip(72).n=[1 inf;1 1];
ip(72).range=[1 inf];
ip(72).values=[];
ip(72).default=[4]; % standard value for acceptors

ip(73).aliases={'g.shr'}; % shr degeneracy factor
ip(73).type='number';
ip(73).n=[1 inf;1 1];
ip(73).range=[-inf inf];
ip(73).values=[];
ip(73).default=[1]; % + for acceptor-like, - for donor-like et'=et+sign(g)*log(abs(g))

ip(74).aliases={'sigma.shr'}; % standard deviation of distribution
ip(74).type='number';
ip(74).n=[1 inf;1 1];
ip(74).range=[0 inf];
ip(74).values=[];
ip(74).default=[0]; % defaults to discrete trap

ip(75).aliases={'nint.shr'}; % # points for integration method
ip(75).type='number';
ip(75).n=[1 inf;1 1];
ip(75).range=[-1 inf];
ip(75).values=[];
ip(75).default=[-1]; % not used if sigma=0, must be set is not a discrete trap

ip(76).aliases={'int_method.shr' 'imeth.shr'};
ip(76).type='string';
ip(76).n=[1 inf;1 1];
ip(76).range=[];
ip(76).values={'Gauss-Hermite' 'Midpoint' 'none'};
ip(76).default={'none'}; 

ip(77).aliases={'distribution.shr' 'distrib.shr'};
ip(77).type='string';
ip(77).n=[1 inf;1 1];
ip(77).range=[];
ip(77).values={'discrete' 'Gaussian' 'uniform'};
ip(77).default={'discrete'};

ip(78).aliases={'half_range.shr' 'hrange.shr'};
ip(78).type='number';
ip(78).n=[1 inf;1 2];
ip(78).range=[eps inf];
ip(78).values=[];
ip(78).default=[100*eps];

ip(79).aliases={'nsigma.shr'}; % +/- sigma range for Midpoint integration of Gaussian
ip(79).type='number';
ip(79).n=[1 inf;1 1];
ip(79).range=[eps inf];
ip(79).values=[];
ip(79).default=[5];

ip(80).aliases={'sigma.slt'}; % standard deviation of distribution
ip(80).type='number';
ip(80).n=[1 inf;1 1];
ip(80).range=[0 inf];
ip(80).values=[];
ip(80).default=[0]; % defaults to discrete trap

ip(81).aliases={'nint.slt'}; % # points for integration method
ip(81).type='number';
ip(81).n=[1 inf;1 1];
ip(81).range=[-1 inf];
ip(81).values=[];
ip(81).default=[-1]; % not used if sigma=0, must be set is not a discrete trap

ip(82).aliases={'int_method.slt' 'imeth.slt'};
ip(82).type='string';
ip(82).n=[1 inf;1 1];
ip(82).range=[];
ip(82).values={'Gauss-Hermite' 'Midpoint' 'none'};
ip(82).default={'none'}; 

ip(83).aliases={'distribution.slt' 'distrib.slt'};
ip(83).type='string';
ip(83).n=[1 inf;1 1];
ip(83).range=[];
ip(83).values={'discrete' 'Gaussian' 'uniform'};
ip(83).default={'discrete'};

ip(84).aliases={'half_range.slt' 'hrange.slt'};
ip(84).type='number';
ip(84).n=[1 inf;1 2];
ip(84).range=[eps inf];
ip(84).values=[];
ip(84).default=[100*eps];

ip(85).aliases={'nsigma.slt'}; % +/- sigma range for Midpoint integration of Gaussian
ip(85).type='number';
ip(85).n=[1 inf;1 1];
ip(85).range=[eps inf];
ip(85).values=[];
ip(85).default=[5];

ip(86).aliases={'sigma.mv3'}; % standard deviation of distribution
ip(86).type='number';
ip(86).n=[1 inf;1 1];
ip(86).range=[0 inf];
ip(86).values=[];
ip(86).default=[0]; % defaults to discrete trap

ip(87).aliases={'nint.mv3'}; % # points for integration method
ip(87).type='number';
ip(87).n=[1 inf;1 1];
ip(87).range=[-1 inf];
ip(87).values=[];
ip(87).default=[-1]; % not used if sigma=0, must be set if not a discrete trap

ip(88).aliases={'int_method.mv3' 'imeth.mv3'};
ip(88).type='string';
ip(88).n=[1 inf;1 1];
ip(88).range=[];
ip(88).values={'Gauss-Hermite' 'Midpoint' 'none'};
ip(88).default={'none'}; 

ip(89).aliases={'distribution.mv3' 'distrib.mv3'};
ip(89).type='string';
ip(89).n=[1 inf;1 1];
ip(89).range=[];
ip(89).values={'discrete' 'Gaussian' 'uniform'};
ip(89).default={'discrete'};

ip(90).aliases={'half_range.mv3' 'hrange.mv3'};
ip(90).type='number';
ip(90).n=[1 inf;1 2];
ip(90).range=[eps inf];
ip(90).values=[];
ip(90).default=[100*eps];

ip(91).aliases={'nsigma.mv3'}; % +/- sigma range for Midpoint integration of Gaussian
ip(91).type='number';
ip(91).n=[1 inf;1 1];
ip(91).range=[eps inf];
ip(91).values=[];
ip(91).default=[5];

ip(92).aliases={'prof.ndp'}; % doping profile
ip(92).type='string';
ip(92).n=[1 inf;1 1];
ip(92).range=[];
ip(92).values={'linear' 'erfc' 'gaussian' 'exp' 'file'};
ip(92).default={'linear'};

ip(93).aliases={'xo.ndp'};
ip(93).type='number';
ip(93).n=[1 inf;1 1];
ip(93).range=[-inf inf];
ip(93).values=[];
ip(93).default=[0];

ip(94).aliases={'dir.ndp'};
ip(94).type='string';
ip(94).n=[1 inf;1 1];
ip(94).range=[];
ip(94).values={'t-b' 'b-t' 'top-bottom' 'bottom-top'};
ip(94).default={'t-b'};

ip(95).aliases={'Dt.ndp'};
ip(95).type='number';
ip(95).n=[1 inf;1 1];
ip(95).range=[eps inf];
ip(95).values=[];
ip(95).default=[inf]; % defaults to constant doping

ip(96).aliases={'L.ndp'};
ip(96).type='number';
ip(96).n=[1 inf;1 1];
ip(96).range=[eps inf];
ip(96).values=[];
ip(96).default=[inf]; % defaults to constant doping

ip(97).aliases={'sigma.ndp'};
ip(97).type='number';
ip(97).n=[1 inf;1 1];
ip(97).range=[eps inf];
ip(97).values=[];
ip(97).default=[inf]; % defaults to constant doping

ip(98).aliases={'prof.nam'}; % doping profile
ip(98).type='string';
ip(98).n=[1 inf;1 1];
ip(98).range=[];
ip(98).values={'linear' 'erfc' 'gaussian' 'exp' 'file'};
ip(98).default={'linear'};

ip(99).aliases={'xo.nam'};
ip(99).type='number';
ip(99).n=[1 inf;1 1];
ip(99).range=[-inf inf];
ip(99).values=[];
ip(99).default=[0];

ip(100).aliases={'dir.nam'};
ip(100).type='string';
ip(100).n=[1 inf;1 1];
ip(100).range=[];
ip(100).values={'t-b' 'b-t' 'top-bottom' 'bottom-top'};
ip(100).default={'t-b'};

ip(101).aliases={'Dt.nam'};
ip(101).type='number';
ip(101).n=[1 inf;1 1];
ip(101).range=[eps inf];
ip(101).values=[];
ip(101).default=[inf]; % defaults to constant doping

ip(102).aliases={'L.nam'};
ip(102).type='number';
ip(102).n=[1 inf;1 1];
ip(102).range=[eps inf];
ip(102).values=[];
ip(102).default=[inf]; % defaults to constant doping

ip(103).aliases={'sigma.nam'};
ip(103).type='number';
ip(103).n=[1 inf;1 1];
ip(103).range=[eps inf];
ip(103).values=[];
ip(103).default=[inf]; % defaults to constant doping

ip(104).aliases={'prof.d'}; % doping profile
ip(104).type='string';
ip(104).n=[1 inf;1 1];
ip(104).range=[];
ip(104).values={'linear' 'erfc' 'gaussian' 'exp' 'file'};
ip(104).default={'linear'};

ip(105).aliases={'xo.d'};
ip(105).type='number';
ip(105).n=[1 inf;1 1];
ip(105).range=[-inf inf];
ip(105).values=[];
ip(105).default=[0];

ip(106).aliases={'dir.d'};
ip(106).type='string';
ip(106).n=[1 inf;1 1];
ip(106).range=[];
ip(106).values={'t-b' 'b-t' 'top-bottom' 'bottom-top'};
ip(106).default={'t-b'};

ip(107).aliases={'Dt.d'};
ip(107).type='number';
ip(107).n=[1 inf;1 1];
ip(107).range=[eps inf];
ip(107).values=[];
ip(107).default=[inf]; % defaults to constant doping

ip(108).aliases={'L.d'};
ip(108).type='number';
ip(108).n=[1 inf;1 1];
ip(108).range=[eps inf];
ip(108).values=[];
ip(108).default=[inf]; % defaults to constant doping

ip(109).aliases={'sigma.d'};
ip(109).type='number';
ip(109).n=[1 inf;1 1];
ip(109).range=[eps inf];
ip(109).values=[];
ip(109).default=[inf]; % defaults to constant doping

ip(110).aliases={'prof.a'}; % doping profile
ip(110).type='string';
ip(110).n=[1 inf;1 1];
ip(110).range=[];
ip(110).values={'linear' 'erfc' 'gaussian' 'exp' 'file'};
ip(110).default={'linear'};

ip(111).aliases={'xo.a'};
ip(111).type='number';
ip(111).n=[1 inf;1 1];
ip(111).range=[-inf inf];
ip(111).values=[];
ip(111).default=[0];

ip(112).aliases={'dir.a'};
ip(112).type='string';
ip(112).n=[1 inf;1 1];
ip(112).range=[];
ip(112).values={'t-b' 'b-t' 'top-bottom' 'bottom-top'};
ip(112).default={'t-b'};

ip(113).aliases={'Dt.a'};
ip(113).type='number';
ip(113).n=[1 inf;1 1];
ip(113).range=[eps inf];
ip(113).values=[];
ip(113).default=[inf]; % defaults to constant doping

ip(114).aliases={'L.a'};
ip(114).type='number';
ip(114).n=[1 inf;1 1];
ip(114).range=[eps inf];
ip(114).values=[];
ip(114).default=[inf]; % defaults to constant doping

ip(115).aliases={'sigma.a'};
ip(115).type='number';
ip(115).n=[1 inf;1 1];
ip(115).range=[eps inf];
ip(115).values=[];
ip(115).default=[inf]; % defaults to constant doping

ip(116).aliases={'alpha_file' 'alpha_file.opt'};
ip(116).type='string';
ip(116).n=[1 1;1 1];
ip(116).range=[];
ip(116).values={'*'};
ip(116).default={''};

ip(117).aliases={'model.un'}; % electron mobility model
ip(117).type='string';
ip(117).n=[1 1;1 1];
ip(117).range=[];
ip(117).values={'linear' 'C-T'};
ip(117).default={'linear'};

ip(118).aliases={'max.un'};
ip(118).type='number';
ip(118).n=[1 1;1 2];
ip(118).range=[eps inf];
ip(118).values=[];
ip(118).default=100;

ip(119).aliases={'min.un'};
ip(119).type='number';
ip(119).n=[1 1;1 2];
ip(119).range=[eps inf];
ip(119).values=[];
ip(119).default=100;

ip(120).aliases={'Nref.un'};
ip(120).type='number';
ip(120).n=[1 1;1 2];
ip(120).range=[eps inf];
ip(120).values=[];
ip(120).default=inf;

ip(121).aliases={'beta.un'};
ip(121).type='number';
ip(121).n=[1 1;1 1];
ip(121).range=[eps inf];
ip(121).values=[];
ip(121).default=1;

ip(122).aliases={'model.up'}; % hole mobility model
ip(122).type='string';
ip(122).n=[1 1;1 1];
ip(122).range=[];
ip(122).values={'linear' 'C-T'};
ip(122).default={'linear'};

ip(123).aliases={'max.up'};
ip(123).type='number';
ip(123).n=[1 1;1 2];
ip(123).range=[eps inf];
ip(123).values=[];
ip(123).default=100;

ip(124).aliases={'min.up'};
ip(124).type='number';
ip(124).n=[1 1;1 2];
ip(124).range=[eps inf];
ip(124).values=[];
ip(124).default=100;

ip(125).aliases={'Nref.up'};
ip(125).type='number';
ip(125).n=[1 1;1 2];
ip(125).range=[eps inf];
ip(125).values=[];
ip(125).default=inf;

ip(126).aliases={'beta.up'};
ip(126).type='number';
ip(126).n=[1 1;1 1];
ip(126).range=[eps inf];
ip(126).values=[];
ip(126).default=1;

ip(127).aliases={'Ncutp.shr'};
ip(127).type='number';
ip(127).n=[1 inf;1 1];
ip(127).range=[eps inf];
ip(127).values=[];
ip(127).default=inf;

ip(128).aliases={'Ncutn.shr'};
ip(128).type='number';
ip(128).n=[1 inf;1 1];
ip(128).range=[eps inf];
ip(128).values=[];
ip(128).default=inf;

% -------------------------------------------------------------------------

[ip kerr]=a_diktat(p,ip,fout); % decode diktat

% % change defaults if not 'custom'
% if strcmp(model,'custom') 
% else
%     error('not yet implemented...')
% end
% -------------------------------------------------------------------------

% check if piece-wise constant
if size(ip(3).set,2) == 1; ip(3).set(:,2)=ip(3).set(:,1); end; % chi
if size(ip(4).set,2) == 1; ip(4).set(:,2)=ip(4).set(:,1); end; % eg
if size(ip(5).set,2) == 1; ip(5).set(:,2)=ip(5).set(:,1); end; % ks
if size(ip(6).set,2) == 1; ip(6).set(:,2)=ip(6).set(:,1); end; % Nc
if size(ip(7).set,2) == 1; ip(7).set(:,2)=ip(7).set(:,1); end; % Nv
if size(ip(8).set,2) == 1; ip(8).set(:,2)=ip(8).set(:,1); end; % Nc.tot
if size(ip(9).set,2) == 1; ip(9).set(:,2)=ip(9).set(:,1); end; % Nv.tot
if size(ip(10).set,2) == 1; ip(10).set(:,2)=ip(10).set(:,1); end; % vth.n
if size(ip(11).set,2) == 1; ip(11).set(:,2)=ip(11).set(:,1); end; % vth.p
if size(ip(12).set,2) == 1; ip(12).set(:,2)=ip(12).set(:,1); end; % Nd+
if size(ip(13).set,2) == 1; ip(13).set(:,2)=ip(13).set(:,1); end; % Na-
if size(ip(14).set,2) == 1; ip(14).set(:,2)=ip(14).set(:,1); end; % un
if size(ip(15).set,2) == 1; ip(15).set(:,2)=ip(15).set(:,1); end; % up
if size(ip(16).set,2) == 1; ip(16).set(:,2)=ip(16).set(:,1); end; % et.shr
if size(ip(17).set,2) == 1; ip(17).set(:,2)=ip(17).set(:,1); end; % taun.shr
if size(ip(18).set,2) == 1; ip(18).set(:,2)=ip(18).set(:,1); end; % taup.shr
if size(ip(19).set,2) == 1; ip(19).set(:,2)=ip(19).set(:,1); end; % B.rad
if size(ip(20).set,2) == 1; ip(20).set(:,2)=ip(20).set(:,1); end; % Cn.auger
if size(ip(21).set,2) == 1; ip(21).set(:,2)=ip(21).set(:,1); end; % Cp.auger
if size(ip(23).set,2) == 1; ip(23).set(:,2)=ip(23).set(:,1); end; % N.d
if size(ip(24).set,2) == 1; ip(24).set(:,2)=ip(24).set(:,1); end; % et.d
if size(ip(26).set,2) == 1; ip(26).set(:,2)=ip(26).set(:,1); end; % cp.d
if size(ip(27).set,2) == 1; ip(27).set(:,2)=ip(27).set(:,1); end; % cn.d
if size(ip(28).set,2) == 1; ip(28).set(:,2)=ip(28).set(:,1); end; % N.a
if size(ip(29).set,2) == 1; ip(29).set(:,2)=ip(29).set(:,1); end; % et.a
if size(ip(31).set,2) == 1; ip(31).set(:,2)=ip(31).set(:,1); end; % cp.a
if size(ip(32).set,2) == 1; ip(32).set(:,2)=ip(32).set(:,1); end; % cn.a
if size(ip(33).set,2) == 1; ip(33).set(:,2)=ip(33).set(:,1); end; % N.slt
if size(ip(35).set,2) == 1; ip(35).set(:,2)=ip(35).set(:,1); end; % et.slt
if size(ip(37).set,2) == 1; ip(37).set(:,2)=ip(37).set(:,1); end; % cp.slt
if size(ip(38).set,2) == 1; ip(38).set(:,2)=ip(38).set(:,1); end; % cn.slt
if size(ip(39).set,2) == 1; ip(39).set(:,2)=ip(39).set(:,1); end; % taup.slt
if size(ip(40).set,2) == 1; ip(40).set(:,2)=ip(40).set(:,1); end; % taun.slt
if size(ip(41).set,2) == 1; ip(41).set(:,2)=ip(41).set(:,1); end; % N.mv3
if size(ip(42).set,2) == 1; ip(42).set(:,2)=ip(42).set(:,1); end; % etp.mv3
if size(ip(43).set,2) == 1; ip(43).set(:,2)=ip(43).set(:,1); end; % etm.mv3
if size(ip(44).set,2) == 1; ip(44).set(:,2)=ip(44).set(:,1); end; % cpp.mv3
if size(ip(45).set,2) == 1; ip(45).set(:,2)=ip(45).set(:,1); end; % cnp.mv3
if size(ip(46).set,2) == 1; ip(46).set(:,2)=ip(46).set(:,1); end; % cpm.mv3
if size(ip(47).set,2) == 1; ip(47).set(:,2)=ip(47).set(:,1); end; % cnm.mv3
if size(ip(48).set,2) == 1; ip(48).set(:,2)=ip(48).set(:,1); end; % eg.opt
if size(ip(49).set,2) == 1; ip(49).set(:,2)=ip(49).set(:,1); end; % A1.opt
if size(ip(53).set,2) == 1; ip(53).set(:,2)=ip(53).set(:,1); end; % FCn.opt
if size(ip(54).set,2) == 1; ip(54).set(:,2)=ip(54).set(:,1); end; % FCp.opt
if size(ip(55).set,2) == 1; ip(55).set(:,2)=ip(55).set(:,1); end; % Bn.opt
if size(ip(56).set,2) == 1; ip(56).set(:,2)=ip(56).set(:,1); end; % Bp.opt
if size(ip(57).set,2) == 1; ip(57).set(:,2)=ip(57).set(:,1); end; % vth
if size(ip(59).set,2) == 1; ip(59).set(:,2)=ip(59).set(:,1); end; % ktv.bt
if size(ip(60).set,2) == 1; ip(60).set(:,2)=ip(60).set(:,1); end; % ktc.bt
if size(ip(61).set,2) == 1; ip(61).set(:,2)=ip(61).set(:,1); end; % Ev.bt
if size(ip(62).set,2) == 1; ip(62).set(:,2)=ip(62).set(:,1); end; % Ec.bt
if size(ip(63).set,2) == 1; ip(63).set(:,2)=ip(63).set(:,1); end; % Nv.bt
if size(ip(64).set,2) == 1; ip(64).set(:,2)=ip(64).set(:,1); end; % Nc.bt
if size(ip(65).set,2) == 1; ip(65).set(:,2)=ip(65).set(:,1); end; % cpv.bt
if size(ip(66).set,2) == 1; ip(66).set(:,2)=ip(66).set(:,1); end; % cnv.bt
if size(ip(67).set,2) == 1; ip(67).set(:,2)=ip(67).set(:,1); end; % cpc.bt
if size(ip(68).set,2) == 1; ip(68).set(:,2)=ip(68).set(:,1); end; % cnc.bt
if size(ip(78).set,2) == 1; ip(78).set(:,2)=ip(78).set(:,1); end; % hrange.shr
if size(ip(84).set,2) == 1; ip(84).set(:,2)=ip(84).set(:,1); end; % hrange.slt
if size(ip(90).set,2) == 1; ip(90).set(:,2)=ip(90).set(:,1); end; % hrange.mv3
if size(ip(118).set,2) == 1; ip(118).set(:,2)=ip(118).set(:,1); end; % max.un
if size(ip(119).set,2) == 1; ip(119).set(:,2)=ip(119).set(:,1); end; % min.un
if size(ip(120).set,2) == 1; ip(120).set(:,2)=ip(120).set(:,1); end; % Nref.un
if size(ip(123).set,2) == 1; ip(123).set(:,2)=ip(123).set(:,1); end; % max.up
if size(ip(124).set,2) == 1; ip(124).set(:,2)=ip(124).set(:,1); end; % min.up
if size(ip(125).set,2) == 1; ip(125).set(:,2)=ip(125).set(:,1); end; % Nref.up

if ip(1).set(1) < 0
    ierr=ierr+1;
    if VERBOSE; fprintf(fout,'Layer thickness not set\n'); end
else
    % convert layer thickness to cm
    if strcmp(ip(1).name,'t_A')
        tt=1e-8*ip(1).set(1);
    elseif strcmp(ip(1).name,'t_nm')
        tt=1e-7*ip(1).set(1);
    elseif strcmp(ip(1).name,'t_um')
        tt=1e-4*ip(1).set(1);
    else
         tt=ip(1).set(1);
    end
end
dev.reg(nlayer).min=thick;
dev.reg(nlayer).max=thick+tt;
dev.reg(nlayer).thick=tt;

dev.reg(nlayer).mat='semiconductor';
try
    matno=length(dev.semi)+1;
catch
    matno=1;
end
dev.reg(nlayer).matno=matno;
dev.semi(matno).reg_no=nlayer;
dev.semi(matno).model=ip(2).set;

%--------------------------------------------------------------------------
% band structure
dev.semi(matno).chi=ip(3).set;
% need this for Schottky barriers
if matno == 1
    dev.bc.top.chi=dev.semi(matno).chi(1,1);
else
    dev.bc.bottom.chi=dev.semi(matno).chi(1,2);
end
dev.semi(matno).eg=ip(4).set;
rEg=dev.semi(matno).eg; % for local use
dev.semi(matno).ks=ip(5).set;
dev.semi(matno).nc=ip(6).set;
rNc=dev.semi(matno).nc; % for local use
% need this for Schottky barriers
if matno == 1
    dev.bc.top.Nc=dev.semi(matno).nc;
else
    dev.bc.bottom.Nc=dev.semi(matno).nc;
end
dev.semi(matno).nv=ip(7).set;
rNv=dev.semi(matno).nv; % for local use
dev.semi(matno).nct=ip(8).set;
dev.semi(matno).nvt=ip(9).set;

%--------------------------------------------------------------------------
% mobility
dev.semi(matno).un_model=ip(117).set;
dev.semi(matno).un=ip(14).set;
dev.semi(matno).un_max=ip(118).set;      
dev.semi(matno).un_min=ip(119).set;
dev.semi(matno).un_nref=ip(120).set;
dev.semi(matno).un_beta=ip(121).set;
dev.semi(matno).up_model=ip(122).set;
dev.semi(matno).up=ip(15).set;
dev.semi(matno).up_max=ip(123).set;      
dev.semi(matno).up_min=ip(124).set;
dev.semi(matno).up_nref=ip(125).set;
dev.semi(matno).up_beta=ip(126).set;

%--------------------------------------------------------------------------
% band-to-band recombination
dev.semi(matno).B=ip(19).set;
dev.semi(matno).Cn=ip(20).set;
dev.semi(matno).Cp=ip(21).set;

%--------------------------------------------------------------------------
% vth
if ip(57).set(1) == 0 % possibly different vthp and vthn
    if ip(10).set(1) == 0
        dev.semi(matno).vthn=[1e7 1e7];
    else
        dev.semi(matno).vthn=ip(10).set;
    end
    if ip(11).set(1) == 0
        dev.semi(matno).vthp=[1e7 1e7];
    else
        dev.semi(matno).vthp=ip(11).set;
    end
elseif ip(57).set(1) > 0 && (ip(10).set(1) > 0 || ip(11).set(1))
    error('rcustom.m: cannot set vth.p/vth.n if vth is set')
else % vthp=vthn
    dev.semi(matno).vthn=ip(57).set;
    dev.semi(matno).vthp=ip(57).set;
end

%--------------------------------------------------------------------------
% fully ionized dopants
% donors
nndp=size(ip(12).set,1);
dev.semi(matno).numndp=nndp;
for kk=1:nndp
    dev.semi(matno).prof_ndp{kk}=ip(92).set{kk};
    % common to all profiles
    dev.semi(matno).ndp(kk,:)=ip(12).set(kk,:);
    % common to erfc,gaussian, exp
    if strcmp((ip(92).set{kk}),'erfc') || strcmp((ip(92).set{kk}),'gaussian') || strcmp((ip(92).set{kk}),'exp')
        try dev.semi(matno).xo_ndp(kk)=ip(93).set(kk); catch dev.semi(matno).xo_ndp(kk)=ip(93).default; end
        try
            if strcmp(ip(94).set(kk),'t-b') || strcmp(ip(94).set(kk),'top-bottom')
                dev.semi(matno).dir_ndp(kk)=1;
            else
                dev.semi(matno).dir_ndp(kk)=-1;
            end
        catch
            dev.semi(matno).dir_ndp(kk)=1;
        end
    end
    switch ip(92).set{kk}
        case 'linear'
             % no extra parameters to set
        case 'erfc'
            try dev.semi(matno).Dt_ndp(kk)=ip(95).set(kk); catch dev.semi(matno).Dt_ndp(kk)=ip(95).default; end
        case 'gaussian'
            try dev.semi(matno).sigma_ndp(kk)=ip(97).set(kk); catch dev.semi(matno).sigma_ndp(kk)=ip(97).default; end
        case 'exp'
            try dev.semi(matno).L_ndp(kk)=ip(96).set(kk); catch dev.semi(matno).L_ndp(kk)=ip(96).default; end
        otherwise
            kerr=kerr+1;
            if VERBOSE; fprintf('a_rcustom.m: profile not supported for .ndp\n'); end
    end
end

% acceptors
nnam=size(ip(13).set,1);
dev.semi(matno).numnam=nnam;
for kk=1:nnam
    dev.semi(matno).prof_nam{kk}=ip(98).set{kk};
    % common to all profiles
    dev.semi(matno).nam(kk,:)=ip(13).set(kk,:);
    % common to erfc,gaussian, exp
    if strcmp((ip(98).set{kk}),'erfc') || strcmp((ip(98).set{kk}),'gaussian') || strcmp((ip(98).set{kk}),'exp')
        try dev.semi(matno).xo_nam(kk)=ip(99).set(kk); catch dev.semi(matno).xo_nam(kk)=ip(99).default; end
        try
            if strcmp(ip(100).set(kk),'t-b') || strcmp(ip(100).set(kk),'top-bottom')
                dev.semi(matno).dir_nam(kk)=1;
            else
                dev.semi(matno).dir_nam(kk)=-1;
            end
        catch
            dev.semi(matno).dir_nam(kk)=1;
        end
    end
    switch ip(98).set{kk}
        case 'linear'
            % no extra parameters to set
        case 'erfc'
            try dev.semi(matno).Dt_nam(kk)=ip(101).set(kk); catch dev.semi(matno).Dt_nam(kk)=ip(101).default; end
        case 'gaussian'
            try dev.semi(matno).sigma_nam(kk)=ip(103).set(kk); catch dev.semi(matno).sigma_nam(kk)=ip(103).default; end
        case 'exp'
            try dev.semi(matno).L_nam(kk)=ip(102).set(kk); catch dev.semi(matno).L_nam(kk)=ip(102).default; end
        otherwise
            kerr=kerr+1;
            if VERBOSE; fprintf('a_rcustom.m: profile not supported for .nam\n'); end
    end
end

%--------------------------------------------------------------------------
% dopants
% donors
nnd=size(ip(23).set,1);
dev.semi(matno).numd=nnd;
for kk=1:nnd
    dev.semi(matno).prof_d{kk}=ip(104).set{kk};
    % common to all profiles
    dev.semi(matno).Nd(kk,:)=ip(23).set(kk,:);
    try dev.semi(matno).Etd(kk,:)=ip(24).set(kk,:); catch dev.semi(matno).Etd(kk,1:2)=ip(24).default; end
    try dev.semi(matno).gd(kk,1)=ip(25).set(kk); catch dev.semi(matno).gd(kk,1)=ip(25).default; end
    try dev.semi(matno).cpd(kk,:)=ip(26).set(kk,:); catch dev.semi(matno).cpd(kk,1:2)=ip(26).default; end
    try dev.semi(matno).cnd(kk,:)=ip(27).set(kk,:); catch dev.semi(matno).cnd(kk,1:2)=ip(27).default; end
    % common to erfc,gaussian, exp
    if strcmp((ip(104).set{kk}),'erfc') || strcmp((ip(104).set{kk}),'gaussian') || strcmp((ip(104).set{kk}),'exp')
        try dev.semi(matno).xo_d(kk)=ip(105).set(kk); catch dev.semi(matno).xo_d(kk)=ip(105).default; end
        try
            if strcmp(ip(106).set(kk),'t-b') || strcmp(ip(106).set(kk),'top-bottom')
                dev.semi(matno).dir_d(kk)=1;
            else
                dev.semi(matno).dir_d(kk)=-1;
            end
        catch
            dev.semi(matno).dir_d(kk)=1;
        end
    end
    switch ip(104).set{kk}
        case 'linear'
            % no extra parameters to set
        case 'erfc'
            try dev.semi(matno).Dt_d(kk)=ip(107).set(kk); catch dev.semi(matno).Dt_d(kk)=ip(107).default; end      
        case 'gaussian'
            try dev.semi(matno).sigma_d(kk)=ip(109).set(kk); catch dev.semi(matno).sigma_d(kk)=ip(109).default; end
        case 'exp'
            try dev.semi(matno).L_d(kk)=ip(108).set(kk); catch dev.semi(matno).L_d(kk)=ip(108).default; end
        otherwise
            kerr=kerr+1;
            if VERBOSE; fprintf('a_rcustom.m: profile not supported for .d\n'); end
    end
end

% acceptors
nna=size(ip(28).set,1);
dev.semi(matno).numa=nna;
for kk=1:nna
    dev.semi(matno).prof_a{kk}=ip(110).set{kk};
    % common to all profiles
    dev.semi(matno).Na(kk,:)=ip(28).set(kk,:);
    try dev.semi(matno).Eta(kk,:)=ip(29).set(kk,:); catch dev.semi(matno).Eta(kk,1:2)=ip(24).default; end
    try dev.semi(matno).ga(kk,1)=ip(30).set(kk); catch dev.semi(matno).ga(kk,1)=ip(25).default; end
    try dev.semi(matno).cpa(kk,:)=ip(31).set(kk,:); catch dev.semi(matno).cpa(kk,1:2)=ip(26).default; end
    try dev.semi(matno).cna(kk,:)=ip(32).set(kk,:); catch dev.semi(matno).cna(kk,1:2)=ip(27).default; end
    % common to erfc, gaussian, exp
    if strcmp((ip(110).set{kk}),'erfc') || strcmp((ip(110).set{kk}),'gaussian') || strcmp((ip(110).set{kk}),'exp')
        try dev.semi(matno).xo_a(kk)=ip(111).set(kk); catch dev.semi(matno).xo_a(kk)=ip(111).default; end
        try
            if strcmp(ip(112).set(kk),'t-b') || strcmp(ip(112).set(kk),'top-bottom')
                dev.semi(matno).dir_a(kk)=1;
            else
                dev.semi(matno).dir_a(kk)=-1;
            end
        catch
            dev.semi(matno).dir_a(kk)=1;
        end
    end
    switch ip(110).set{kk}
        case 'linear'
            % no extra parameters to set
        case 'erfc'
            try dev.semi(matno).Dt_a(kk)=ip(113).set(kk); catch dev.semi(matno).Dt_a(kk)=ip(113).default; end
        case 'gaussian'
            try dev.semi(matno).sigma_a(kk)=ip(115).set(kk); catch dev.semi(matno).sigma_a(kk)=ip(115).default; end
        case 'exp'
            try dev.semi(matno).L_a(kk)=ip(114).set(kk); catch dev.semi(matno).L_a(kk)=ip(114).default; end
        otherwise
            kerr=kerr+1;
            if VERBOSE; fprintf('a_rcustom.m: profile not supported for .a\n'); end
    end
end

%--------------------------------------------------------------------------
% shr recombination
nshr=size(ip(16).set,1);

for kk=1:nshr % check for valid inputs
   switch char(ip(77).set(kk)) % distribution.shr
       case 'discrete'
           if ip(75).set(kk) ~= -1
               error('a_rcustom.m: nint.shr must = -1 (not used)')
           else
               ip(75).set(kk)=1; % set to one for calculations
           end
           if ip(74).set(kk) ~= 0
               error('a_rcustom.m: sigma.shr must = 0 for discrete trap')
           end
           if strcmp(ip(76).set(kk),'none') == 0
               error('a_rcustom.m: int_method.shr must = ''none'' for discrete trap')
           end
       case 'Gaussian'
           if ip(74).set(kk) == 0
               error('a_rcustom.m: sigma.shr must > 0 for Gaussian trap distribution')
           end
           if ip(76).default_used
               ip(76).set(kk)={'Gauss-Hermite'};
               if ip(75).default_used
                   ip(75).set(kk)=15; % default value
               end
           else
               if strcmp(ip(76).set(kk),'Gauss-Hermite')
                   if ip(75).default_used
                       ip(75).set(kk)=15; % default value
                   end
               elseif strcmp(ip(76).set(kk),'Midpoint')
                   if ip(75).default_used
                       ip(75).set(kk)=20; % default value
                   end
               end
           end
           if strcmp(ip(76).set(kk),'none') % int_method.shr
              error('a_rcustom.m: int_method.shr must = ''Gauss-Hermite'' or ''Midpoint'' for Gaussian distribution')
           end
           if ip(75).set(kk) < 2 && strcmp(ip(76).set(kk),'Gauss-Hermite')
               error('a_rcustom.m: nint.shr must be >= 2 for ''Gauss-Hermite'' integration')
           end
           if ip(75).set(kk) < 1 && strcmp(ip(76).set(kk),'Midpoint')
               error('a_rcustom.m: nint.shr must be >= 1 for ''Midpoint'' integration')
           end
       case 'uniform'
           if ip(74).set(kk) ~= 0
               error('a_rcustom.m: sigma.shr not used for uniform trap distribution')
           end
           if ip(76).default_used
               ip(76).set(kk)={'Midpoint'};
               if ip(75).default_used
                   ip(75).set(kk)=20; % default value
               end
           end
           if strcmp(ip(76).set(kk),'none') || strcmp(ip(76).set(kk),'Gauss-Hermite')
              error('a_rcustom.m: int_method.shr must = ''Midpoint'' for uniform trap distribution')
           end
           if ip(75).set(kk) < 1
               error('a_rcustom.m: nint.shr must be >= 1')
           end
           if ip(78).set(kk,1) < eps || ip(78).set(kk,2) < eps
               error('a_rcustom.m: half_range.shr must be >= eps')
           end
   end
end
 
numshr=0; % multiple shr centers
for l1=1:size(ip(16).set,1) 
   if strcmp(ip(77).set(l1),'Gaussian') && strcmp(ip(76).set(l1),'Gauss-Hermite')
       [hxi,hwi]=Gauss_Hermite(ip(75).set(l1));
   elseif strcmp(ip(77).set(l1),'Gaussian') && strcmp(ip(76).set(l1),'Midpoint')
       Ebot=ip(16).set(l1,:)-ip(79).set(l1)*ip(74).set(l1,:);
       Etop=ip(16).set(l1,:)+ip(79).set(l1)*ip(74).set(l1,:);
       rne=ip(75).set(l1);
       delE=(Etop-Ebot)/rne;
       ret(1,:)=Ebot(1):delE(1):Etop(1);
       ret(2,:)=Ebot(2):delE(2):Etop(2);
       mei(:,1:rne)=0.5*(ret(:,1:rne)+ret(:,2:rne+1));
   elseif strcmp(ip(77).set(l1),'uniform') && strcmp(ip(76).set(l1),'Midpoint')
       Ebot=ip(16).set(l1,:)-ip(78).set(l1,:);
       Etop=ip(16).set(l1,:)+ip(78).set(l1,:);
       rne=ip(75).set(l1);
       delE=(Etop-Ebot)/rne;
       ret(1,:)=Ebot(1):delE(1):Etop(1);
       ret(2,:)=Ebot(2):delE(2):Etop(2);
       mei(:,1:rne)=0.5*(ret(:,1:rne)+ret(:,2:rne+1));
   elseif strcmp(ip(77).set(l1),'discrete')
       % nothing to do
   else
       error('a_rcustom.m: this should not happen')
   end
   
   for l2=1:ip(75).set(l1)
     numshr=numshr+1;
     dev.semi(matno).shr_species(numshr)=l1;
     if strcmp(ip(77).set(l1),'discrete')
         dev.semi(matno).shrdist(numshr)={'discrete'};
         dev.semi(matno).et(numshr,:)=ip(16).set(l1,:)+sign(ip(73).set(l1)).*log(abs(ip(73).set(l1))');
         dev.semi(matno).taup(numshr,:)=ip(17).set(l1,:);
         dev.semi(matno).taun(numshr,:)=ip(18).set(l1,:);
     elseif strcmp(ip(77).set(l1),'Gaussian')
         dev.semi(matno).shrdist{numshr}='Gaussian';
         if strcmp(ip(76).set(l1),'Gauss-Hermite')
             zzi=2*hwi(l2)*exp(-hxi(l2)^2)/sqrt(2*pi);
             Ett=ip(16).set(l1,:)+sign(ip(73).set(l1)).*log(abs(ip(73).set(l1))');
             dev.semi(matno).et(numshr,:)=Ett+sqrt(2)*ip(74).set(l1)*hxi(l2);
             dev.semi(matno).taup(numshr,:)=ip(17).set(l1,:)/zzi;
             dev.semi(matno).taun(numshr,:)=ip(18).set(l1,:)/zzi;
         elseif strcmp(ip(76).set(kk),'Midpoint')
             zxi=delE.*exp(-(mei(:,l2)').^2/2/ip(74).set(l1)^2)./sqrt(2*pi)/ip(74).set(l1);
             dev.semi(matno).et(numshr,:)=mei(:,l2)+sign(ip(73).set(l1)).*log(abs(ip(73).set(l1))');
             dev.semi(matno).taup(numshr,:)=ip(17).set(l1,:)./zxi;
             dev.semi(matno).taun(numshr,:)=ip(18).set(l1,:)./zxi;                
         else
             error('a_rcustom.m: integration method not implemented')
         end
     elseif strcmp(ip(77).set(l1),'uniform') % Midpoint integration
         dev.semi(matno).shrdist{numshr}='uniform';
         dev.semi(matno).et(numshr,:)=mei(:,l2)+sign(ip(73).set(l1)).*log(abs(ip(73).set(l1))');
         dev.semi(matno).taup(numshr,:)=ip(17).set(l1,:).*(Etop-Ebot)./delE;
         dev.semi(matno).taun(numshr,:)=ip(18).set(l1,:).*(Etop-Ebot)./delE;
     else
         error('a_rcustom.m: distribution type not implemented')
     end
   end
end
dev.semi(matno).numshr=numshr;

%----------------------------------------------------------------------
% amphoteric (mv3)

nmv3=size(ip(33).set,1);
for kk=1:nmv3 % check for valid inputs
   switch char(ip(89).set(kk)) % distribution.mv3
       case 'discrete'
           if ip(87).set(kk) ~= -1
               error('a_rcustom.m: nint.mv3 must = -1 (not used)')
           else
               ip(87).set(kk)=1; % set to one for calculations
           end
           if ip(86).set(kk) ~= 0
               error('a_rcustom.m: sigma.mv3 must = 0 for discrete trap')
           end
           if strcmp(ip(88).set(kk),'none') == 0
               error('a_rcustom.m: int_method.mv3 must = ''none'' for discrete trap')
           end
       case 'Gaussian'
           if ip(86).set(kk) == 0
               error('a_rcustom.m: sigma.mv3 must > 0 for Gaussian trap distribution')
           end
           if ip(88).default_used
               ip(88).set(kk)={'Gauss-Hermite'};
               if ip(87).default_used
                   ip(87).set(kk)=15; % default value
               end
           else
               if strcmp(ip(88).set(kk),'Gauss-Hermite')
                   if ip(87).default_used
                       ip(87).set(kk)=15; % default value
                   end
               elseif strcmp(ip(88).set(kk),'Midpoint')
                   if ip(87).default_used
                       ip(87).set(kk)=20; % default value
                   end
               end
           end
           if strcmp(ip(88).set(kk),'none') % int_method.slt
              error('a_rcustom.m: int_method.mv3 must = ''Gauss-Hermite'' or ''Midpoint'' for Gaussian distribution')
           end
           if ip(87).set(kk) < 2 && strcmp(ip(88).set(kk),'Gauss-Hermite')
               error('a_rcustom.m: nint.mv3 must be >= 2 for ''Gauss-Hermite'' integration')
           end
           if ip(87).set(kk) < 1 && strcmp(ip(88).set(kk),'Midpoint')
               error('a_rcustom.m: nint.mv3 must be >= 1 for ''Midpoint'' integration')
           end
       case 'uniform'
           if ip(86).set(kk) ~= 0
               error('a_rcustom.m: sigma.mv3 not used for uniform trap distribution')
           end
           if ip(88).default_used
               ip(88).set(kk)={'Midpoint'};
               if ip(87).default_used
                   ip(87).set(kk)=20; % default value
               end
           end
           if strcmp(ip(88).set(kk),'none') || strcmp(ip(88).set(kk),'Gauss-Hermite')
              error('a_rcustom.m: int_method.mv3 must = ''Midpoint'' for uniform trap distribution')
           end
           if ip(87).set(kk) < 1
               error('a_rcustom.m: nint.mv3 must be >= 1')
           end
           if ip(90).set(kk,1) < eps || ip(90).set(kk,2) < eps
               error('a_rcustom.m: half_range.mv3 must be >= eps')
           end
   end
end
 
nummv3=0; % multiple mv3 centers
for l1=1:size(ip(41).set,1) 
   if strcmp(ip(89).set(l1),'Gaussian') && strcmp(ip(88).set(l1),'Gauss-Hermite')
       [hxi,hwi]=Gauss_Hermite(ip(81).set(l1));
   elseif strcmp(ip(89).set(l1),'Gaussian') && strcmp(ip(88).set(l1),'Midpoint')
       Ebotp=ip(42).set(l1,:)-ip(91).set(l1)*ip(86).set(l1,:);
       Etopp=ip(42).set(l1,:)+ip(91).set(l1)*ip(86).set(l1,:);
       Ebotm=ip(43).set(l1,:)-ip(91).set(l1)*ip(86).set(l1,:);
       Etopm=ip(43).set(l1,:)+ip(91).set(l1)*ip(86).set(l1,:);
       rne=ip(87).set(l1);
       delEp=(Etopp-Ebotp)/rne;
       delEn=(Etopn-Ebotn)/rne;
       retp(1,:)=Ebotp(1):delEp(1):Etopp(1);
       retp(2,:)=Ebotp(2):delEp(2):Etopp(2);
       retn(1,:)=Ebotn(1):delEn(1):Etopn(1);
       retp(2,:)=Ebotn(2):delEn(2):Etopn(2);
       meip(:,1:rne)=0.5*(retp(:,1:rne)+retp(:,2:rne+1));
       mein(:,1:rne)=0.5*(retn(:,1:rne)+retn(:,2:rne+1));
   elseif strcmp(ip(89).set(l1),'uniform') && strcmp(ip(88).set(l1),'Midpoint')
       Ebotp=ip(42).set(l1,:)-ip(90).set(l1,:);
       Etopp=ip(42).set(l1,:)+ip(90).set(l1,:);
       Ebotn=ip(43).set(l1,:)-ip(90).set(l1,:);
       Etopn=ip(43).set(l1,:)+ip(90).set(l1,:);
       rne=ip(87).set(l1);
       delEp=(Etopp-Ebotp)/rne;
       delEn=(Etopn-Ebotn)/rne;
       retp(1,:)=Ebotp(1):delEp(1):Etopp(1);
       retp(2,:)=Ebotp(2):delEp(2):Etopp(2);
       retn(1,:)=Ebotn(1):delEn(1):Etopn(1);
       retp(2,:)=Ebotn(2):delEn(2):Etopn(2);
       meip(:,1:rne)=0.5*(retp(:,1:rne)+retp(:,2:rne+1));
       mein(:,1:rne)=0.5*(retn(:,1:rne)+retn(:,2:rne+1));
   elseif strcmp(ip(89).set(l1),'discrete')
       % nothing to do
   else
       error('a_rcustom.m: this should not happen')
   end
   for l2=1:ip(87).set(l1)
     nummv3=nummv3+1;
     dev.semi(matno).slt_species(nummv3)=l1;
     if strcmp(ip(89).set(l1),'discrete')
         dev.semi(matno).sltdist(nummv3)={'discrete'};
         dev.semi(matno).Nmv3(nummv3,:)=ip(41).set(l1,:);
         dev.semi(matno).Etp3(nummv3,:)=ip(42).set(l1,:);
         dev.semi(matno).Etm3(nummv3,:)=ip(43).set(l1,:);
         dev.semi(matno).cpp3(nummv3,:)=ip(44).set(l1,:);
         dev.semi(matno).cnp3(nummv3,:)=ip(45).set(l1,:);
         dev.semi(matno).cpm3(nummv3,:)=ip(46).set(l1,:);
         dev.semi(matno).cnm3(nummv3,:)=ip(47).set(l1,:);
     elseif strcmp(ip(89).set(l1),'Gaussian')
         dev.semi(matno).sltdist{nummv3}='Gaussian';
         if strcmp(ip(88).set(l1),'Gauss-Hermite')
             zzi=2*hwi(l2)*exp(-hxi(l2)^2)/sqrt(2*pi);
             dev.semi(matno).Nmv3(nummv3,:)=ip(41).set(l1,:).*zzi;
             dev.semi(matno).Etp3(nummv3,:)=ip(42).set(l1,:)+sqrt(2)*ip(86).set(l1)*hxi(l2);
             dev.semi(matno).Etm3(nummv3,:)=ip(43).set(l1,:)+sqrt(2)*ip(86).set(l1)*hxi(l2);
             dev.semi(matno).cpp3(nummv3,:)=ip(44).set(l1,:);
             dev.semi(matno).cnp3(nummv3,:)=ip(45).set(l1,:);
             dev.semi(matno).cpm3(nummv3,:)=ip(46).set(l1,:);
             dev.semi(matno).cnm3(nummv3,:)=ip(47).set(l1,:);
         elseif strcmp(ip(88).set(kk),'Midpoint')
             zxi=delE.*exp(-(mei(:,l2)').^2/2/ip(80).set(l1)^2)./sqrt(2*pi)/ip(74).set(l1);
             dev.semi(matno).Nmv3(nummv3,:)=ip(41).set(l1,:).*zxi;
             dev.semi(matno).Etp3(nummv3,:)=meip(:,l2);
             dev.semi(matno).Etm3(nummv3,:)=mein(:,l2);
             dev.semi(matno).cpp3(nummv3,:)=ip(44).set(l1,:);
             dev.semi(matno).cnp3(nummv3,:)=ip(45).set(l1,:);
             dev.semi(matno).cpm3(nummv3,:)=ip(46).set(l1,:);
             dev.semi(matno).cnm3(nummv3,:)=ip(47).set(l1,:);               
         else
             error('a_rcustom.m: integration method not implemented')
         end
     elseif strcmp(ip(89).set(l1),'uniform') % Midpoint integration
         dev.semi(matno).sltdist{nummv3}='uniform';
         dev.semi(matno).Nmv3(nummv3,:)=ip(41).set(l1,:).*delEp./(Etopp-Ebotp);
         dev.semi(matno).Etp3(nummv3,:)=meip(:,l2);
         dev.semi(matno).Etm3(nummv3,:)=mein(:,l2);
         dev.semi(matno).cpp3(nummv3,:)=ip(44).set(l1,:);
         dev.semi(matno).cnp3(nummv3,:)=ip(45).set(l1,:);
         dev.semi(matno).cpm3(nummv3,:)=ip(46).set(l1,:);
         dev.semi(matno).cnm3(nummv3,:)=ip(47).set(l1,:);
     else
         error('a_rcustom.m: distribution type not implemented')
     end
   end
end
dev.semi(matno).nummv3=nummv3;

%--------------------------------------------------------------------------
% slt recombination

%set cp.slt and cn.slt
if ip(37).default_used == 1
    ip(37).set=[1e-14 1e-14];
    ip(37).default=[1e-14 1e-14];
end
if ip(38).default_used == 1
    ip(38).set=[1e-14 1e-14];
    ip(38).default=[1e-14 1e-14];
end

if ip(39).default_used == 0 && ip(37).default_used == 1
    ip(37).set=1./ip(39).set./dev.semi(matno).vthp./ip(33).set; %cp
elseif ip(39).default_used == 0 && ip(37).default_used == 0
    error('a_rcustom.m: cannot set both taup.slt and cp.slt')
end
if ip(40).default_used == 0 && ip(38).default_used == 1
    ip(38).set=1./ip(40).set./dev.semi(matno).vthn./ip(33).set; %cn
elseif ip(40).default_used == 0 && ip(38).default_used == 0
    error('a_rcustom.m: cannot set both taup.slt and cp.slt')
end

nslt=size(ip(33).set,1);
for kk=1:nslt % check for valid inputs
   if ip(33).set(kk,1) > 0 || ip(33).set(kk,1) > 0
       if strcmp(ip(34).set(kk),'off')
           error('a_rcustom.m: slt trap type must be set to donor or acceptor')
       end
   end
   switch char(ip(83).set(kk)) % distribution.slt
       case 'discrete'
           if ip(81).set(kk) ~= -1
               error('a_rcustom.m: nint.slt must = -1 (not used)')
           else
               ip(81).set(kk)=1; % set to one for calculations
           end
           if ip(80).set(kk) ~= 0
               error('a_rcustom.m: sigma.slt must = 0 for discrete trap')
           end
           if strcmp(ip(82).set(kk),'none') == 0
               error('a_rcustom.m: int_method.slt must = ''none'' for discrete trap')
           end
       case 'Gaussian'
           if ip(80).set(kk) == 0
               error('a_rcustom.m: sigma.slt must > 0 for Gaussian trap distribution')
           end
           if ip(82).default_used
               ip(82).set(kk)={'Gauss-Hermite'};
               if ip(81).default_used
                   ip(81).set(kk)=15; % default value
               end
           else
               if strcmp(ip(82).set(kk),'Gauss-Hermite')
                   if ip(81).default_used
                       ip(81).set(kk)=15; % default value
                   end
               elseif strcmp(ip(82).set(kk),'Midpoint')
                   if ip(81).default_used
                       ip(81).set(kk)=20; % default value
                   end
               end
           end
           if strcmp(ip(82).set(kk),'none') % int_method.slt
              error('a_rcustom.m: int_method.slt must = ''Gauss-Hermite'' or ''Midpoint'' for Gaussian distribution')
           end
           if ip(81).set(kk) < 2 && strcmp(ip(82).set(kk),'Gauss-Hermite')
               error('a_rcustom.m: nint.slt must be >= 2 for ''Gauss-Hermite'' integration')
           end
           if ip(81).set(kk) < 1 && strcmp(ip(82).set(kk),'Midpoint')
               error('a_rcustom.m: nint.slt must be >= 1 for ''Midpoint'' integration')
           end
       case 'uniform'
           if ip(80).set(kk) ~= 0
               error('a_rcustom.m: sigma.slt not used for uniform trap distribution')
           end
           if ip(82).default_used
               ip(82).set(kk)={'Midpoint'};
               if ip(81).default_used
                   ip(81).set(kk)=20; % default value
               end
           end
           if strcmp(ip(82).set(kk),'none') || strcmp(ip(82).set(kk),'Gauss-Hermite')
              error('a_rcustom.m: int_method.slt must = ''Midpoint'' for uniform trap distribution')
           end
           if ip(81).set(kk) < 1
               error('a_rcustom.m: nint.slt must be >= 1')
           end
           if ip(84).set(kk,1) < eps || ip(84).set(kk,2) < eps
               error('a_rcustom.m: half_range.slt must be >= eps')
           end
   end
end
 
numslt=0; % multiple slt centers
for l1=1:size(ip(33).set,1) 
   if strcmp(ip(83).set(l1),'Gaussian') && strcmp(ip(82).set(l1),'Gauss-Hermite')
       [hxi,hwi]=Gauss_Hermite(ip(81).set(l1));
   elseif strcmp(ip(83).set(l1),'Gaussian') && strcmp(ip(82).set(l1),'Midpoint')
%            Ebot=-rEg/2-dev.const.kb*dev.T/2*log(rNv./rNc);
%            Etop=Ebot+rEg;
       Ebot=ip(35).set(l1,:)-ip(85).set(l1)*ip(80).set(l1,:);
       Etop=ip(35).set(l1,:)+ip(85).set(l1)*ip(80).set(l1,:);
       rne=ip(81).set(l1);
       delE=(Etop-Ebot)/rne;
       ret(1,:)=Ebot(1):delE(1):Etop(1);
       ret(2,:)=Ebot(2):delE(2):Etop(2);
       mei(:,1:rne)=0.5*(ret(:,1:rne)+ret(:,2:rne+1));
   elseif strcmp(ip(83).set(l1),'uniform') && strcmp(ip(82).set(l1),'Midpoint')
       Ebot=ip(35).set(l1,:)-ip(84).set(l1,:);
       Etop=ip(35).set(l1,:)+ip(84).set(l1,:);
       rne=ip(81).set(l1);
       delE=(Etop-Ebot)/rne;
       ret(1,:)=Ebot(1):delE(1):Etop(1);
       ret(2,:)=Ebot(2):delE(2):Etop(2);
       mei(:,1:rne)=0.5*(ret(:,1:rne)+ret(:,2:rne+1));
   elseif strcmp(ip(83).set(l1),'discrete')
       % nothing to do
   else
       error('a_rcustom.m: this should not happen')
   end
   for l2=1:ip(81).set(l1)
     numslt=numslt+1;
     dev.semi(matno).slt_species(numslt)=l1;
     if strcmp(ip(83).set(l1),'discrete')
         dev.semi(matno).sltdist(numslt)={'discrete'};
         dev.semi(matno).Nslt(numslt,:)=ip(33).set(l1,:);
         dev.semi(matno).slt_type{numslt}=ip(34).set{l1};
         dev.semi(matno).Etslt(numslt,:)=ip(35).set(l1,:);
         dev.semi(matno).gslt(numslt,:)=ip(36).set(l1);
         dev.semi(matno).cpslt(numslt,:)=ip(37).set(l1,:);
         dev.semi(matno).cnslt(numslt,:)=ip(38).set(l1,:);
     elseif strcmp(ip(83).set(l1),'Gaussian')
         dev.semi(matno).sltdist{numslt}='Gaussian';
         if strcmp(ip(82).set(l1),'Gauss-Hermite')
             zzi=2*hwi(l2)*exp(-hxi(l2)^2)/sqrt(2*pi);
             dev.semi(matno).Nslt(numslt,:)=ip(33).set(l1,:).*zzi;
             dev.semi(matno).slt_type{numslt}=ip(34).set{l1};
             dev.semi(matno).Etslt(numslt,:)=ip(35).set(l1,:)+sqrt(2)*ip(80).set(l1)*hxi(l2);
             dev.semi(matno).gslt(numslt,:)=ip(36).set(l1);
             dev.semi(matno).cpslt(numslt,:)=ip(37).set(l1,:);
             dev.semi(matno).cnslt(numslt,:)=ip(38).set(l1,:);
         elseif strcmp(ip(82).set(kk),'Midpoint')
             zxi=delE.*exp(-(mei(:,l2)').^2/2/ip(80).set(l1)^2)./sqrt(2*pi)/ip(74).set(l1);
             dev.semi(matno).Nslt(numslt,:)=ip(33).set(l1,:).*zxi;
             dev.semi(matno).slt_type{numslt}=ip(34).set{l1};
             dev.semi(matno).Etslt(numslt,:)=mei(:,l2);
             dev.semi(matno).gslt(numslt,:)=ip(36).set(l1);
             dev.semi(matno).cpslt(numslt,:)=ip(37).set(l1,:);
             dev.semi(matno).cnslt(numslt,:)=ip(38).set(l1,:);                
         else
             error('a_rcustom.m: integration method not implemented')
         end
     elseif strcmp(ip(83).set(l1),'uniform') % Midpoint integration
         dev.semi(matno).sltdist{numslt}='uniform';
         dev.semi(matno).Nslt(numslt,:)=ip(33).set(l1,:).*delE./(Etop-Ebot);
         dev.semi(matno).slt_type{numslt}=ip(34).set{l1};
         dev.semi(matno).Etslt(numslt,:)=mei(:,l2);
         dev.semi(matno).gslt(numslt,:)=ip(36).set(l1);
         dev.semi(matno).cpslt(numslt,:)=ip(37).set(l1,:);
         dev.semi(matno).cnslt(numslt,:)=ip(38).set(l1,:);
     else
         error('a_rcustom.m: distribution type not implemented')
     end
   end
end
dev.semi(matno).numslt=numslt;

%--------------------------------------------------------------------------
% band tails
dev.semi(matno).btail=char(ip(58).set{1});
dev.semi(matno).nbtquad=0;
if strcmp(dev.semi(matno).btail,'on')
    if ip(63).set(1,1) < 0 || ip(63).set(1,2) < 0
        dev.semi(matno).gvbt=2*pi*dev.semi(matno).nv/(CONST.kb*dev.T*pi)^1.5*sqrt(CONST.kb*dev.T);
    else
        dev.semi(matno).gvbt=ip(63).set;
    end
    if ip(64).set(1,1) < 0 || ip(64).set(1,2) < 0
        dev.semi(matno).gcbt=2*pi*dev.semi(matno).nc/(CONST.kb*dev.T*pi)^1.5*sqrt(CONST.kb*dev.T);
    else
        dev.semi(matno).gcbt=ip(64).set;
    end
    dev.semi(matno).ktvb=ip(59).set; % ktv.bt
    dev.semi(matno).ktcb=ip(60).set; % ktc.bt
    dev.semi(matno).dEvb=ip(61).set; % dEv.bt
    dev.semi(matno).dEcb=ip(62).set; % dEc.bt
    if dev.semi(matno).dEvb(1) > 0 ||...
       dev.semi(matno).dEvb(2) > 0 ||...
       dev.semi(matno).dEvb(1) > 0 ||...
       dev.semi(matno).dEvb(2) > 0
           error('dEv.bt, dEc.bt ~= 0 not implemented')
    end
    dev.semi(matno).cpvb=ip(65).set; % cpv.bt
    dev.semi(matno).cnvb=ip(66).set; % cnv.bt
    dev.semi(matno).cpcb=ip(67).set; % cpc.bt
    dev.semi(matno).cncb=ip(68).set; % cnc.bt
    dev.semi(matno).nbtquad=ip(69).set; % nlaguerre.bt
    dev.semi(matno).btstep=ip(70).set; % maxEstep.bt
    dev.semi(matno).gdb=ip(71).set; % gd.bt
    dev.semi(matno).gab=ip(72).set; % ga.bt
    nbtquad=dev.semi(matno).nbtquad;
    [lxi,lwi,~]=Gauss_Laguerre(nbtquad);
    % valence band tails [donor-like; effective density, effective trap energies wrt Ec, Eteff=Ec-Et] 
    dev.semi(matno).Nvbt_eff(1:nbtquad,1)=dev.semi(matno).ktvb(1).*dev.semi(matno).gvbt(1)*lwi';
    dev.semi(matno).Nvbt_eff(1:nbtquad,2)=dev.semi(matno).ktvb(2).*dev.semi(matno).gvbt(2)*lwi';
    dev.semi(matno).etvbt_eff(1:nbtquad,1)=dev.semi(matno).eg(1)-dev.semi(matno).ktvb(1)*lxi';
    dev.semi(matno).etvbt_eff(1:nbtquad,2)=dev.semi(matno).eg(2)-dev.semi(matno).ktvb(2)*lxi';
    % conduction band tails [acceptor-like; effective density, effective trap energies wrt Ev, Eteff=Et-Ev]
    dev.semi(matno).Ncbt_eff(1:nbtquad,1)=dev.semi(matno).ktcb(1).*dev.semi(matno).gcbt(1)*lwi';
    dev.semi(matno).Ncbt_eff(1:nbtquad,2)=dev.semi(matno).ktcb(2).*dev.semi(matno).gcbt(2)*lwi';
    dev.semi(matno).etcbt_eff(1:nbtquad,1)=dev.semi(matno).eg(1)-dev.semi(matno).ktcb(1)*lxi';
    dev.semi(matno).etcbt_eff(1:nbtquad,2)=dev.semi(matno).eg(2)-dev.semi(matno).ktcb(2)*lxi';
elseif ip(58).default_used == 0
    if VERBOSE; fprintf('CAUTION: btail explicitly turned off, so band tail parameters are not used.\n'); end
else
    if ip(59).default_used == 0 || ip(60).default_used == 0 || ip(61).default_used == 0 || ...
       ip(62).default_used == 0 || ip(63).default_used == 0 || ip(64).default_used == 0 || ...
       ip(65).default_used == 0 || ip(66).default_used == 0 || ip(67).default_used == 0 || ...
       ip(68).default_used == 0 || ip(69).default_used == 0 || ip(70).default_used == 0 || ...
       ip(71).default_used == 0 || ip(72).default_used == 0
       error('Band tail parameters set, but btail=''off''')
    end
end

%--------------------------------------------------------------------------
% absortion coeff info
dev.semi(matno).alpha_model=char(ip(22).set{1});
if strcmp(dev.semi(matno).alpha_model,'none') || strcmp(dev.semi(matno).alpha_model,'simple')
    if size(ip(48).set,1) == size(ip(49).set,1) &&...
        size(ip(48).set,1) == size(ip(50).set,1) &&...
        size(ip(48).set,1) == size(ip(51).set,1)
        dev.Optical.opt_abs_model(nlayer).A1=ip(49).set;
        dev.Optical.opt_abs_model(nlayer).A2=ip(50).set;
        dev.Optical.opt_abs_model(nlayer).A3=ip(51).set;
        dev.Optical.opt_abs_model(nlayer).numalf=size(ip(48).set,1);
    else
       error('--- size of Eg.opt, A1, A2, A3 must be the same\n')
    end    
    dev.Optical.opt_abs_model(nlayer).alpha_model=dev.semi(matno).alpha_model;
    dev.Optical.opt_abs_model(nlayer).Eg=ip(48).set;
    for kr=1:size(ip(48).set,1)
        for kc=1:size(ip(48).set,2)
            if dev.Optical.opt_abs_model(nlayer).Eg(kr,kc) < 0
                dev.Optical.opt_abs_model(nlayer).Eg=dev.semi(matno).eg;
            end
            if strcmp(dev.Optical.opt_abs_model(nlayer).alpha_model,'none') && dev.Optical.opt_abs_model(nlayer).A1(kr,kc) > 0
                error('--- if alpha_model is ''none'', A1 must be zero\n')
            end
        end
    end
elseif strcmp(dev.semi(matno).alpha_model,'file')
     dev.Optical.opt_abs_model(nlayer).alpha_model=dev.semi(matno).alpha_model;
     alpha_file=char(ip(116).set{1});
     dev.Optical.opt_abs_model(nlayer).alpha_data=a_ralpha(alpha_file);
else
    error('absorption model not implemented')
end

%--------------------------------------------------------------------------
% parasitic absorption info
dev.semi(matno).alpha_fc=char(ip(52).set{1});
dev.Optical.opt_abs_model(nlayer).alpha_fc=dev.semi(matno).alpha_fc;
dev.Optical.opt_abs_model(nlayer).fcn=ip(53).set;
dev.Optical.opt_abs_model(nlayer).fcp=ip(54).set;
dev.Optical.opt_abs_model(nlayer).bn=ip(55).set;
dev.Optical.opt_abs_model(nlayer).bp=ip(56).set;
if strcmp(dev.Optical.opt_abs_model(nlayer).alpha_fc,'off')
    if dev.Optical.opt_abs_model(nlayer).fcn(1,1) > 0 || dev.Optical.opt_abs_model(nlayer).fcp(1,1) > 0 ||...
       dev.Optical.opt_abs_model(nlayer).fcn(1,2) > 0 || dev.Optical.opt_abs_model(nlayer).fcp(1,2) > 0
        error('--- if alpha_model is ''off'', FCn and FCp must be zero\n')
    end
end

dev.reg(nlayer).rip=ip;
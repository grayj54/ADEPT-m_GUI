function list = getBuiltDevices
    % Iterates through device folder and makes a list of device
    % names.

    list = {};
end
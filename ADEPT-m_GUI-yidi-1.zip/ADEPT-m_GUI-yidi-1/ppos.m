function z=ppos(z)
z(z<0)=0;